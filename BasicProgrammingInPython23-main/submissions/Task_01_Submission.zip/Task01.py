
#Name: Noah Schepers
#Matrikelnummer: 1001753
#E-Mail: noschepers@uni-osnabrueck.de

#Task 1
#"""
a = "hello world"
b = -19
c = 7.29
d = False
e = (1, 2, 4.56)
f = ["a", "b", "c"]
g = 9 >= 9
h = 28 * 2 - 14
#"""

#"""
#Task 2
a = 1
b = 2
c = 5.37
d = 7.92

(a+b)/(c/d)

(a+b+c+d)/4

(a**2+b**2)/(1+(c/d))

(a-b)**(0.5)
#"""

#"""
#Task 3
print("Number 1: ")
a = int(input())
print("Number 2: ")
b = int(input())

c = a
a = b
b = c
print(a, b)
#"""

#"""
#Task 4
print("Height: ")
height = int(input())
print("Age: ")
age = int(input())

if height < 120: print("The Person", {height}, "cm ", {age}, "years old is not allowed to take the ride.")
elif age < 12: price = 5
elif age < 18: price = 8
else: price = 15

if height > 120: print("The Person ", {height}, "cm ", {age}, "years old has to pay ", {price}, "� for the ride.")
#"""